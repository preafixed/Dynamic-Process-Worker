# Dynamic-Process-Worker
Python library for creating and managing Process Workers with an optional GUI
